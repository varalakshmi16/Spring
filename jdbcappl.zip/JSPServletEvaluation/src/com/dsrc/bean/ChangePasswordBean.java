package com.dsrc.bean;

public class ChangePasswordBean {

	/*
	 * 	Use this bean for password change .
	 * 	
	 *  Create variables for loginid ,old password , new password and confirm password
	 *  Create getters and setters..
	 * 
	 * */
	private String LoginId;
	private String OldPassword;
	private String NewPassword;

	public String getLoginId() {
		return LoginId;
	}
	public void setLoginId(String loginId) {
		LoginId = loginId;
	}
	public String getOldPassword() {
		return OldPassword;
	}
	public void setOldPassword(String oldPassword) {
		OldPassword = oldPassword;
	}
	public String getNewPassword() {
		return NewPassword;
	}
	public void setNewPassword(String newPassword) {
		NewPassword = newPassword;
	}
	
	
}
