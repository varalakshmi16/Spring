package com.dsrc.bean;

public class LoginBean 
{
	/*
	 * Create private variables for Login.
	 * Create getters and setters
	 * */
	private String LoginId;
	private String Password;
	public String getLoginId() {
		return LoginId;
	}
	public void setLoginId(String loginId) {
		LoginId = loginId;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}

}
