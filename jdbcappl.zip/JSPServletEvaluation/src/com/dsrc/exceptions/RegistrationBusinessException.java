package com.dsrc.exceptions;

public class RegistrationBusinessException extends Exception {

	public RegistrationBusinessException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
