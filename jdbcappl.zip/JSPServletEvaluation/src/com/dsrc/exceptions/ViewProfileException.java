package com.dsrc.exceptions;

public class ViewProfileException extends Exception {

	public ViewProfileException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
