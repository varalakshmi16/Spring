package com.dsrc.exceptions;

public class RegistrationException extends Exception {

	public RegistrationException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
