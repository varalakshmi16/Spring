package com.dsrc.exceptions;

public class LoginBusinessException extends Exception {
	
	public LoginBusinessException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
}
}